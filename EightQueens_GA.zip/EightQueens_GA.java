import java.util.Scanner;

class EightQueens_GA{
	static Scanner scanner= new Scanner(System.in);
	static final int boardNum = 8;
	static table POP[] = new table[10];

	static table crossOver(table x, table y){
		int board[] = new int[boardNum];

		for(int i = 0; i < boardNum; i ++){
			if(i < boardNum / 2)
				board[i] = x.board[i];
			else
				board[i] = y.board[i];
		}

		if((int)(Math.random()*100) < 1){
			int mutate = (int)(Math.random()*board.length);

			board[mutate] = (int)(Math.random()*board.length);
		}

		table newT = new table(board);

		return newT;
	}

	static void sortPOP(table x[]){
		for(int i = 0; i < x.length; i++){
			System.out.print(x[i].conflictAll() + ",");
		}
	}



	public static void main(String[] args) {
		for(int i = 0; i < POP.length; i++){
			POP[i] = new table(8);
			POP[i].showBoard();//���`
		}
		
		for(int i = 0; i < POP.length; i++){
			POP[i].showBoard();//�ǩǪ�
		}

	}
}